#!/usr/bin/env python3
"""Validate a submission CSV before it is submitted."""

import argparse
import os
import sys
import pandas as pd


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--submission", required=True)
    parser.add_argument("--test", default="test.csv")
    parser.add_argument("--target", default="target")
    parser.add_argument("--id-col", default=None)
    args = parser.parse_args()

    errors, warnings = [], []

    if not os.path.exists(args.submission):
        print(f"FAIL: submission file '{args.submission}' not found.")
        sys.exit(1)

    sub = pd.read_csv(args.submission)

    if args.target not in sub.columns:
        errors.append(f"missing target column '{args.target}'")

    id_col = args.id_col
    if id_col is None:
        for cand in ("id", "Id", "ID"):
            if cand in sub.columns:
                id_col = cand
                break

    if os.path.exists(args.test):
        test_df = pd.read_csv(args.test)
        if len(sub) != len(test_df):
            errors.append(f"row count mismatch: submission has {len(sub)}, test.csv has {len(test_df)}")
        if id_col and id_col in test_df.columns:
            if set(sub[id_col]) != set(test_df[id_col]):
                errors.append(f"id column '{id_col}' does not match test.csv ids exactly")
    else:
        warnings.append(f"'{args.test}' not found, skipping row-count/id checks")

    if args.target in sub.columns:
        if sub[args.target].isna().any():
            errors.append(f"target column has {sub[args.target].isna().sum()} NaN values")
        if sub[args.target].nunique() == 1:
            warnings.append("target column is constant across all rows - likely a bug")

    if id_col and sub[id_col].duplicated().any():
        errors.append(f"id column '{id_col}' has duplicate values")

    for w in warnings:
        print(f"WARN: {w}")

    if errors:
        for e in errors:
            print(f"FAIL: {e}")
        sys.exit(1)

    print(f"PASS: '{args.submission}' looks valid ({len(sub)} rows).")


if __name__ == "__main__":
    main()
