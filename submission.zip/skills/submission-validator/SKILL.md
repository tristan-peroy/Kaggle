---
name: submission-validator
description: >-
  Validates a prediction CSV's shape, columns, and value sanity before it is
  submitted, to avoid wasting a submission on a malformed file.
---

# Submission Validator Skill

## Available Scripts

### 1. `validate_submission.py`

**Usage via `run_skill_script`**:
```python
run_skill_script(
    skill_name="submission-validator",
    script_name="validate_submission.py",
    args="--submission preds_ensemble.csv --test test.csv --target target",
)
```

**Arguments**:
- `--submission`: Path to the prediction CSV to validate.
- `--test`: Path to the original `test.csv` (used to check row count / id match).
- `--target`: Expected prediction column name.
- `--id-col`: ID column name (auto-detected from `id`/`Id`/`ID` if omitted).

**Behavior**: Prints a PASS/FAIL report and exits with code 1 on any
failure (wrong row count, missing columns, NaNs, id mismatch/duplicates,
constant predictions). Run this before every `submit_predictions` call.
