---
name: model-trainer
description: >-
  Trains and cross-validates baseline ML models (tree-based and linear),
  reports CV scores, and writes test-set predictions for each model.
---

# Model Trainer Skill

Runs k-fold cross-validation for a set of baseline models and saves
predictions, so the agent doesn't need to rewrite training/CV code from
scratch each iteration.

## Available Scripts

### 1. `train_models.py`

**Usage via `run_skill_script`**:
```python
run_skill_script(
    skill_name="model-trainer",
    script_name="train_models.py",
    args="--train train_engineered.csv --test test_engineered.csv --target target --task-type classification --models rf,gbm,linear --cv 5",
)
```

**Arguments**:
- `--train` / `--test`: Paths to engineered CSVs.
- `--target`: Target column name.
- `--task-type`: `classification` or `regression` (auto-detected if omitted).
- `--models`: Comma-separated list from `rf`, `gbm`, `linear` (default: all three).
- `--cv`: Number of CV folds (default: 5).
- `--id-col`: ID column to carry through to prediction files (auto-detected
  from `id`/`Id`/`ID` if omitted).

**Outputs**:
- Prints per-model mean/std CV score to stdout.
- Writes `cv_scores.json` with all scores.
- Writes `preds_<model>.csv` (id + prediction) for each model, fit on full
  training data — ready to feed into the `ensembler` skill or
  `submit_predictions` directly.
