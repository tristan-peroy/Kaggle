#!/usr/bin/env python3
"""Train and cross-validate baseline models, save CV scores and predictions."""

import argparse
import json
import os
import sys
import numpy as np
import pandas as pd
from sklearn.model_selection import KFold, StratifiedKFold
from sklearn.ensemble import RandomForestClassifier, RandomForestRegressor
from sklearn.ensemble import GradientBoostingClassifier, GradientBoostingRegressor
from sklearn.linear_model import LogisticRegression, Ridge
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import roc_auc_score, accuracy_score, mean_squared_error


def detect_task_type(y):
    if y.dtype == object or y.nunique() <= 20:
        return "classification"
    return "regression"


def get_model(name, task_type):
    if task_type == "classification":
        return {
            "rf": RandomForestClassifier(n_estimators=300, random_state=42, n_jobs=-1),
            "gbm": GradientBoostingClassifier(random_state=42),
            "linear": LogisticRegression(max_iter=1000, random_state=42),
        }[name]
    else:
        return {
            "rf": RandomForestRegressor(n_estimators=300, random_state=42, n_jobs=-1),
            "gbm": GradientBoostingRegressor(random_state=42),
            "linear": Ridge(random_state=42),
        }[name]


def score(y_true, y_pred, task_type):
    if task_type == "classification":
        try:
            return roc_auc_score(y_true, y_pred)
        except Exception:
            return accuracy_score(y_true, np.round(y_pred))
    rmse = np.sqrt(mean_squared_error(y_true, y_pred))
    return -rmse  # higher (less negative) = better, kept consistent w/ "higher is better"


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--train", default="train_engineered.csv")
    parser.add_argument("--test", default="test_engineered.csv")
    parser.add_argument("--target", default="target")
    parser.add_argument("--task-type", default=None, choices=[None, "classification", "regression"])
    parser.add_argument("--models", default="rf,gbm,linear")
    parser.add_argument("--cv", type=int, default=5)
    parser.add_argument("--id-col", default=None)
    args = parser.parse_args()

    for path in (args.train, args.test):
        if not os.path.exists(path):
            print(f"Error: file '{path}' not found.")
            sys.exit(1)

    train_df = pd.read_csv(args.train)
    test_df = pd.read_csv(args.test)

    if args.target not in train_df.columns:
        print(f"Error: target '{args.target}' not in train.")
        sys.exit(1)

    y = train_df[args.target]
    task_type = args.task_type or detect_task_type(y)
    print(f"Task type: {task_type}")

    id_col = args.id_col
    if id_col is None:
        for cand in ("id", "Id", "ID"):
            if cand in test_df.columns:
                id_col = cand
                break

    feature_cols = [c for c in train_df.columns if c != args.target and c in test_df.columns]
    X = train_df[feature_cols].select_dtypes(include=[np.number]).fillna(0)
    X_test = test_df[feature_cols].select_dtypes(include=[np.number]).fillna(0)
    common = [c for c in X.columns if c in X_test.columns]
    X, X_test = X[common], X_test[common]

    y_enc = y.astype("category").cat.codes if y.dtype == object else y

    model_names = [m.strip() for m in args.models.split(",") if m.strip()]
    results = {}

    scaler = StandardScaler()
    X_scaled = pd.DataFrame(scaler.fit_transform(X), columns=X.columns, index=X.index)
    X_test_scaled = pd.DataFrame(scaler.transform(X_test), columns=X_test.columns, index=X_test.index)

    splitter = (StratifiedKFold(n_splits=args.cv, shuffle=True, random_state=42)
                if task_type == "classification"
                else KFold(n_splits=args.cv, shuffle=True, random_state=42))

    for name in model_names:
        try:
            fold_scores = []
            use_scaled = (name == "linear")
            data_X = X_scaled if use_scaled else X
            split_arg = y_enc if task_type == "classification" else None
            for train_idx, val_idx in splitter.split(data_X, split_arg):
                model = get_model(name, task_type)
                model.fit(data_X.iloc[train_idx], y_enc.iloc[train_idx])
                if task_type == "classification" and hasattr(model, "predict_proba"):
                    val_pred = model.predict_proba(data_X.iloc[val_idx])[:, 1]
                else:
                    val_pred = model.predict(data_X.iloc[val_idx])
                fold_scores.append(score(y_enc.iloc[val_idx], val_pred, task_type))

            mean_score, std_score = float(np.mean(fold_scores)), float(np.std(fold_scores))
            results[name] = {"mean_cv_score": mean_score, "std_cv_score": std_score}
            print(f"{name}: mean_cv_score={mean_score:.5f} (+/- {std_score:.5f})")

            final_model = get_model(name, task_type)
            final_data_X = X_scaled if use_scaled else X
            final_test_X = X_test_scaled if use_scaled else X_test
            final_model.fit(final_data_X, y_enc)
            if task_type == "classification" and hasattr(final_model, "predict_proba"):
                test_pred = final_model.predict_proba(final_test_X)[:, 1]
            else:
                test_pred = final_model.predict(final_test_X)

            out = pd.DataFrame({args.target: test_pred})
            if id_col and id_col in test_df.columns:
                out.insert(0, id_col, test_df[id_col].values)
            out.to_csv(f"preds_{name}.csv", index=False)
            print(f"  saved preds_{name}.csv")
        except Exception as exc:
            print(f"[skip] model '{name}' failed: {exc}")

    with open("cv_scores.json", "w") as f:
        json.dump(results, f, indent=2)
    print("Saved cv_scores.json")


if __name__ == "__main__":
    main()
