# Data Leakage Prevention Checklist

Data leakage occurs when information from outside the training dataset is used to create the model, leading to overly optimistic performance estimates during local validation and catastrophic failure on the private leaderboard.

When performing feature engineering, strictly adhere to the following principles:

## Target Leakage Prevention
- **Rule**: Ensure no feature is directly derived from or highly correlated with the target column in a way that would not be available at true inference time.
- Watch for features that are proxies for the target (e.g., a column that's a rounded or shifted version of it).

## Fit-on-Train, Transform-on-Test
- **Rule**: Any statistic used for a transform (imputation medians, encoding frequencies, scaling parameters, quantile bin edges) must be computed on the training set only, then applied unchanged to the test set.
- Never fit an imputer, encoder, or scaler on train+test combined.

## Train/Test Distribution Shift
- **Rule**: If a feature's distribution differs substantially between train and test (check the `data_analyst`'s KS-test / PSI output), treat it with suspicion — it may not generalize, or may indicate a collection-process difference rather than a genuine signal.
- Consider dropping or down-weighting high-shift features if they don't clearly help CV score.

## Temporal Leakage
- **Rule**: If any column encodes time/order (dates, sequence IDs), never use future rows to construct features for past rows. Row-wise aggregations across a single row's own features are safe; aggregations that use "future" information relative to a row's timestamp are not.

## Aggregation Leakage
- **Rule**: Row-wise aggregations (mean/std/min/max across a single row's own features) are safe. Column-wise aggregations across the training set (e.g., group means, target encoding) must be fit per-CV-fold when used inside cross-validation, not on the full training set before splitting, or the CV score will be optimistic.

## Validation Discipline
- **Rule**: Use the same CV strategy you'll effectively be judged on. A mismatch between your local CV setup and the leaderboard's public/private split is a common source of surprises — prefer stratified folds for classification and check for any grouping structure that should keep related rows in the same fold.
