#!/usr/bin/env python3
"""Robust CLI script for automated feature generation.

Identifies column types, imputes missing values, encodes categoricals,
adds row-wise aggregations, numeric interactions, and quantile binning.
All transforms are fit on train and applied to test to avoid leakage.
"""

import argparse
import os
import sys
import numpy as np
import pandas as pd
from sklearn.impute import SimpleImputer


def detect_task_type(target_series):
    if target_series is None:
        return "regression"
    if target_series.dtype == object or target_series.nunique() <= 20:
        return "classification"
    return "regression"


def safe_step(name, fn):
    """Run a feature step, warn and continue on failure instead of crashing."""
    try:
        fn()
        print(f"  [ok] {name}")
    except Exception as exc:
        print(f"  [skip] {name} failed: {exc}")


def main():
    parser = argparse.ArgumentParser(description="Generate automated ML features.")
    parser.add_argument("--train", type=str, default="train.csv")
    parser.add_argument("--test", type=str, default="test.csv")
    parser.add_argument("--target", type=str, default="target")
    parser.add_argument("--task-type", type=str, default=None,
                         choices=[None, "classification", "regression"])
    parser.add_argument("--onehot-max-cardinality", type=int, default=10,
                         help="Categorical columns with <= this many unique "
                              "values are one-hot encoded; above it, "
                              "frequency-encoded instead.")
    args = parser.parse_args()

    print(f"Loading datasets: {args.train}, {args.test}...")
    for path in (args.train, args.test):
        if not os.path.exists(path):
            print(f"Error: file '{path}' not found.")
            sys.exit(1)

    train_df = pd.read_csv(args.train)
    test_df = pd.read_csv(args.test)

    target_series = None
    if args.target in train_df.columns:
        target_series = train_df[args.target].copy()
        train_df = train_df.drop(columns=[args.target])
    else:
        print(f"Warning: target column '{args.target}' not found in train.")

    task_type = args.task_type or detect_task_type(target_series)
    print(f"Task type: {task_type}")

    # Align columns
    common_cols = [c for c in train_df.columns if c in test_df.columns]
    train_df = train_df[common_cols].copy()
    test_df = test_df[common_cols].copy()
    print(f"Initial shape: train={train_df.shape}, test={test_df.shape}")

    num_cols = train_df.select_dtypes(include=[np.number]).columns.tolist()
    cat_cols = train_df.select_dtypes(exclude=[np.number]).columns.tolist()

    # Missing-value count feature (computed before imputation)
    def add_missing_count():
        train_df["missing_count"] = train_df[common_cols].isna().sum(axis=1)
        test_df["missing_count"] = test_df[common_cols].isna().sum(axis=1)
    safe_step("missing_count feature", add_missing_count)

    # 1. Impute (fit on train, transform test)
    if num_cols:
        def impute_numeric():
            imputer = SimpleImputer(strategy="median")
            train_df[num_cols] = imputer.fit_transform(train_df[num_cols])
            test_df[num_cols] = imputer.transform(test_df[num_cols])
        safe_step(f"impute {len(num_cols)} numeric columns", impute_numeric)

    if cat_cols:
        def impute_categorical():
            imputer = SimpleImputer(strategy="most_frequent")
            train_df[cat_cols] = imputer.fit_transform(train_df[cat_cols])
            test_df[cat_cols] = imputer.transform(test_df[cat_cols])
        safe_step(f"impute {len(cat_cols)} categorical columns", impute_categorical)

    # 2. Row-wise numeric aggregations
    if num_cols:
        def add_aggregations():
            train_df["row_mean"] = train_df[num_cols].mean(axis=1)
            test_df["row_mean"] = test_df[num_cols].mean(axis=1)
            train_df["row_std"] = train_df[num_cols].std(axis=1)
            test_df["row_std"] = test_df[num_cols].std(axis=1)
            train_df["row_min"] = train_df[num_cols].min(axis=1)
            test_df["row_min"] = test_df[num_cols].min(axis=1)
            train_df["row_max"] = train_df[num_cols].max(axis=1)
            test_df["row_max"] = test_df[num_cols].max(axis=1)
        safe_step("row-wise mean/std/min/max", add_aggregations)

    # 3. Numeric interactions (top-variance columns only, to avoid feature blow-up)
    if len(num_cols) >= 2:
        def add_interactions():
            top_cols = train_df[num_cols].var().sort_values(ascending=False).index[:5].tolist()
            for i in range(len(top_cols)):
                for j in range(i + 1, len(top_cols)):
                    a, b = top_cols[i], top_cols[j]
                    train_df[f"{a}_x_{b}"] = train_df[a] * train_df[b]
                    test_df[f"{a}_x_{b}"] = test_df[a] * test_df[b]
                    denom_train = train_df[b].replace(0, np.nan)
                    denom_test = test_df[b].replace(0, np.nan)
                    train_df[f"{a}_div_{b}"] = (train_df[a] / denom_train).fillna(0)
                    test_df[f"{a}_div_{b}"] = (test_df[a] / denom_test).fillna(0)
        safe_step("top-variance numeric interactions", add_interactions)

    # 4. Quantile binning of skewed numeric features
    if num_cols:
        def add_bins():
            skewed = train_df[num_cols].skew().abs().sort_values(ascending=False)
            skewed_cols = skewed[skewed > 1.0].index[:5].tolist()
            for col in skewed_cols:
                bins = pd.qcut(train_df[col], q=5, duplicates="drop", retbins=True)[1]
                bins[0], bins[-1] = -np.inf, np.inf
                train_df[f"{col}_bin"] = pd.cut(train_df[col], bins=bins, labels=False)
                test_df[f"{col}_bin"] = pd.cut(test_df[col], bins=bins, labels=False)
        safe_step("quantile binning of skewed columns", add_bins)

    # 5. Categorical encoding (fit on train, applied to test)
    if cat_cols:
        def encode_categoricals():
            low_card = [c for c in cat_cols if train_df[c].nunique() <= args.onehot_max_cardinality]
            high_card = [c for c in cat_cols if c not in low_card]

            if low_card:
                combined = pd.concat([train_df[low_card], test_df[low_card]], axis=0)
                dummies = pd.get_dummies(combined, columns=low_card, dummy_na=False)
                train_dummies = dummies.iloc[:len(train_df)].reset_index(drop=True)
                test_dummies = dummies.iloc[len(train_df):].reset_index(drop=True)
                for c in low_card:
                    train_df.drop(columns=[c], inplace=True)
                    test_df.drop(columns=[c], inplace=True)
                for c in train_dummies.columns:
                    train_df[c] = train_dummies[c].values
                    test_df[c] = test_dummies[c].values if c in test_dummies.columns else 0

            for c in high_card:
                freq = train_df[c].value_counts(normalize=True)
                train_df[f"{c}_freq"] = train_df[c].map(freq).fillna(0)
                test_df[f"{c}_freq"] = test_df[c].map(freq).fillna(0)
                train_df.drop(columns=[c], inplace=True)
                test_df.drop(columns=[c], inplace=True)
        safe_step(f"encode {len(cat_cols)} categorical columns", encode_categoricals)

    # Re-attach target
    if target_series is not None:
        train_df[args.target] = target_series

    print(f"Engineered shape: train={train_df.shape}, test={test_df.shape}")
    train_df.to_csv("train_engineered.csv", index=False)
    test_df.to_csv("test_engineered.csv", index=False)
    print("Saved train_engineered.csv and test_engineered.csv successfully.")


if __name__ == "__main__":
    main()
