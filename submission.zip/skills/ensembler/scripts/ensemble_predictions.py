#!/usr/bin/env python3
"""Blend multiple prediction CSVs into a single ensembled prediction."""

import argparse
import json
import os
import sys
import numpy as np
import pandas as pd


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--preds", required=True, help="Comma-separated prediction CSV paths")
    parser.add_argument("--target", default="target")
    parser.add_argument("--method", default="mean", choices=["mean", "weighted"])
    parser.add_argument("--scores", default="cv_scores.json")
    parser.add_argument("--output", default="preds_ensemble.csv")
    args = parser.parse_args()

    paths = [p.strip() for p in args.preds.split(",") if p.strip()]
    if len(paths) < 2:
        print("Error: need at least 2 prediction files to ensemble.")
        sys.exit(1)

    dfs, names = [], []
    for p in paths:
        if not os.path.exists(p):
            print(f"Error: '{p}' not found.")
            sys.exit(1)
        dfs.append(pd.read_csv(p))
        base = os.path.basename(p)
        names.append(base.replace("preds_", "").replace(".csv", ""))

    id_col = None
    for cand in ("id", "Id", "ID"):
        if cand in dfs[0].columns:
            id_col = cand
            break

    n_rows = len(dfs[0])
    for i, df in enumerate(dfs):
        if len(df) != n_rows:
            print(f"Error: '{paths[i]}' has {len(df)} rows, expected {n_rows}.")
            sys.exit(1)
        if args.target not in df.columns:
            print(f"Error: '{paths[i]}' missing target column '{args.target}'.")
            sys.exit(1)

    weights = [1.0] * len(dfs)
    if args.method == "weighted":
        if not os.path.exists(args.scores):
            print(f"Error: scores file '{args.scores}' not found, needed for weighted method.")
            sys.exit(1)
        with open(args.scores) as f:
            score_map = json.load(f)
        raw_weights = []
        for name in names:
            if name in score_map:
                raw_weights.append(max(score_map[name]["mean_cv_score"], 1e-6))
            else:
                print(f"Warning: no CV score found for '{name}', using weight 1.0")
                raw_weights.append(1.0)
        total = sum(raw_weights)
        weights = [w / total for w in raw_weights]
        print(f"Weights: {dict(zip(names, weights))}")

    stacked = np.average(
        np.column_stack([df[args.target].values for df in dfs]),
        axis=1,
        weights=weights,
    )

    out = pd.DataFrame({args.target: stacked})
    if id_col:
        out.insert(0, id_col, dfs[0][id_col].values)
    out.to_csv(args.output, index=False)
    print(f"Saved ensembled predictions to {args.output} (blended {names})")


if __name__ == "__main__":
    main()
