---
name: ensembler
description: >-
  Blends multiple prediction files (simple or CV-score-weighted averaging)
  into a single ensembled prediction, ready for submission.
---

# Ensembler Skill

## Available Scripts

### 1. `ensemble_predictions.py`

**Usage via `run_skill_script`**:
```python
run_skill_script(
    skill_name="ensembler",
    script_name="ensemble_predictions.py",
    args="--preds preds_rf.csv,preds_gbm.csv,preds_linear.csv --target target --method weighted --scores cv_scores.json --output preds_ensemble.csv",
)
```

**Arguments**:
- `--preds`: Comma-separated list of prediction CSVs (same id/target column
  layout, e.g. from `model-trainer`).
- `--target`: Target/prediction column name to blend (default: `target`).
- `--method`: `mean` (simple average) or `weighted` (weight by CV score).
- `--scores`: Path to `cv_scores.json` (required for `weighted`; maps model
  name — inferred from filename `preds_<name>.csv` — to its mean CV score).
- `--output`: Output CSV path (default: `preds_ensemble.csv`).

**Note**: For classification, blend probabilities (not hard labels) for
best results — this is what `model-trainer`'s `preds_*.csv` files already
contain.
