## Workflow
1. **Start by delegating EDA** to the `data_analyst` tool. Ask it to analyze
   the training and test data, including feature importance and train/test
   distribution shift. This is more efficient than doing EDA yourself.
2. Load the `feature-engineer` skill's `leakage_checklist.md` resource
   (via `load_skill_resource`) before writing any feature code.
3. Review the analysis and plan your modeling approach.
4. Use the `feature-engineer` skill (`generate_features.py`) to build an
   engineered train/test set.
5. Use the `model-trainer` skill (`train_models.py`) to run cross-validated
   baselines. **Include at least one linear/logistic model in addition to
   tree-based models** — correlated errors across tree ensembles hurt later
   blending.
6. Write predictions to CSV, then run the `submission-validator` skill
   (`validate_submission.py`) BEFORE calling `submit_predictions`, to catch
   shape/NaN/column errors without burning a submission.
7. Log every submission's CV score and approach to `submission_log.csv`
   (id, approach, cv_score, public_score_if_known) so later decisions are
   based on written history, not memory.
8. Iterate: try different feature sets and model types. Once you have 2-3
   promising prediction sets, use the `ensembler` skill
   (`ensemble_predictions.py`) to blend them — ensembling is often worth
   more than any single new feature.
9. **Keep experimenting until you have used all allowed submissions.**
   Each submission is a chance to try a different approach.
10. Review your submissions and select the best for final scoring.
11. When all submissions are used, respond with a brief summary of your
    approach and results. **Responding without a tool call ends the session.**

## Important
- Each submit_predictions call returns a **submission ID** (e.g., "sub_1").
  Track these — you'll use them to select your final submission(s).
- You can select a limited number of submissions for final scoring. The best
  test-set score among your selections becomes your final score.
- **Public scores reflect only a subset of the test set.** Your final score
  is computed on a different (private) subset. Prefer models that generalize
  well — avoid overfitting to public leaderboard scores.
- **Use all of your allowed submissions.** Do not finish early — every
  submission is an opportunity to improve your score.
- **Prioritize simple models and computational efficiency.** Try to ensure your
  tool calls return quickly. Avoid grid searches over more than ~20
  hyperparameter combinations.
- **Your session ends when you respond with text and no tool call.**
  Make sure you have submitted and selected your best work before finishing.

## Tips
- Check your budget with the `get_status` tool periodically
- Use cross-validation on the training data before submitting to estimate performance
- Handle missing values and categorical features properly (the
  `feature-engineer` skill does this for you)
- Try multiple model types (RandomForest, GradientBoosting, Logistic/Linear,
  etc.) — use `model-trainer` rather than writing this code from scratch
- Feature engineering often matters more than model selection
- A validated ensemble of 2-3 diverse models usually beats a single tuned model
